# Lava PvP — Prototype (Static Web)

This folder is a lightweight static prototype of Lava PvP UI and assets. It is intended to be served as a static site (GitHub Pages, Netlify, or local file server).

## How to open
- Open `public/index.html` in a modern browser (or serve the folder with a static server).

## Included
- `public/index.html` — main page (uses React + Tailwind via CDN)
- `assets/icons/*.svg` — operator icons
- `assets/map_sketch.svg` — map preview
- `design/abilities.json` — JSON with ability numbers

This is a front-end prototype only (no game engine yet). Use these assets to build the full game in Godot/Unity/etc.
